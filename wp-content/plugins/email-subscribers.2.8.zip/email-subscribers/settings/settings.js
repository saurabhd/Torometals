function _es_redirect()
{
	window.location = "admin.php?page=es-settings";
}

function _es_help()
{
	window.open("http://www.gopiplus.com/work/2014/05/02/email-subscribers-wordpress-plugin/");
}